#!/bin/sh
python tools/patcher.py  --patch-config patch/patch.cfg
