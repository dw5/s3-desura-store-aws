// Copyright (c) 2009 The Chromium Embedded Framework Authors. All rights
// reserved. Use of this source code is governed by a BSD-style license that
// can be found in the LICENSE file.

#include "test_suite.h"

int main(int argc, char** argv) {
  return CefTestSuite(argc, argv).Run();
}
