#!/bin/sh
python tools/gclient_hook.py
